import datetime
import json
import random

_DOWNLOAD_PATH = "Download/"
_N = 0


class NewspaperArticle:
    def __init__(self, headline, reporter, body):
        self.headline = headline
        self.reporter = reporter
        self.body = body
        self.likes = random.randint(0, 100)
        self.publication_date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def generate_random_headline():
    """Генерирует случайный заголовок статьи газеты из предустановленных шаблонов."""
    templates = [
        "Скандал: {noun} {verb}",
        "Эксклюзив: {verb} {noun}",
        "Новые данные о {noun}",
        "Почему {noun} важен для общества",
        "Будущее {noun}: что нас ждет",
    ]
    nouns = ["политика", "экономика", "экология", "спорт", "культура"]
    verbs = ["изменяет", "влияет", "привлекает", "разрушает", "поддерживает"]

    template = random.choice(templates)
    headline = template.format(
        noun=random.choice(nouns),
        verb=random.choice(verbs)
    )
    return headline


def json_dump_newspaper_article(article: NewspaperArticle):
    global _N
    _N += 1
    dt = datetime.datetime.now()
    dt_str = dt.strftime('%Y-%m-%d_%H-%M-%S')
    path = f'{_DOWNLOAD_PATH}{_N}_{dt_str}.json'

    # Открываем файл с указанием кодировки utf-8
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(article.__dict__, f, ensure_ascii=False)


def get_newspaper_article():
    headline = generate_random_headline()
    reporter = f"Репортер {random.randint(1, 100)}"
    body = f"Это содержание статьи с заголовком '{headline}'."
    article = NewspaperArticle(headline, reporter, body)
    return article


def do_work():
    article = get_newspaper_article()
    json_dump_newspaper_article(article)


# Создание и сохранение 10 статей газеты
for _ in range(10):
    do_work()

print('Успешно выполнено!')