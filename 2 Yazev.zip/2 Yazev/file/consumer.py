import time
import sched
import json
import random
from datetime import datetime
import shutil
import os
from os import walk

class Article:
    def __init__(self, title, body):
        self.title = title
        self.body = body
        self.datetime = datetime.now().strftime("%A %d-%b-%Y %H:%M:%S")
        self.likes = random.randint(10, 100)

_I = 20
LOG_FILE = f'json/log/deserialize-{datetime.now().strftime("%Y%m%d")}.log'
_PATH_DOWN = "json/download/"

def log(message):
    """Записывает сообщение в лог-файл."""
    with open(LOG_FILE, "a") as f:
        f.writelines(f'{datetime.now().strftime("%H:%M:%S")} | {message} \n')

def print_article(article):
    """Выводит информацию о статье и записывает в лог."""
    print(article.title, article.body, article.datetime, article.likes, sep='\n')
    log(f'Данные обработаны: {article.title}')

def read_file(path, file_name):
    """Читает JSON-файл и возвращает его содержимое."""
    with open(f'{path}{file_name}', "r") as f:
        return json.load(f)

def copy_file(file_name):
    """Копирует файл в директорию загруженных."""
    shutil.copy(f'{_PATH_DOWN}{file_name}', "json/loaded/")

def error_copy_file(file_name):
    """Копирует файл в директорию ошибок."""
    shutil.copy(f'json/error/{file_name}', "json/loaded/")

def remove_file(file_name):
    """Удаляет файл из директории загрузки."""
    os.remove(f'{_PATH_DOWN}{file_name}')

def from_dict(data, file_name):
    """Создает объект Article из словаря."""
    try:
        article = Article(data["title"], data["body"])
        article.datetime = data.get("datetime", article.datetime)
        article.likes = data.get("likes", article.likes)
        copy_file(file_name)
        return article
    except Exception as err:
        log(f'Ошибка - {err}')
        error_copy_file(file_name)
    finally:
        remove_file(file_name)

def watch_dir(path):
    """Просматривает директорию на наличие файлов и обрабатывает их."""
    for root, dirs, files in walk(path):
        for file in files:
            log(f'Обнаружен файл: {file}')
            art_load = read_file(path, file)
            art = from_dict(art_load, file)
            if art:
                print_article(art)

def do_work(sc):
    """Основная функция для планирования работы."""
    global _I
    print(f'--- Осталось итераций: {_I} ---')
    watch_dir(_PATH_DOWN)
    _I -= 1
    if _I > 0:
        s.enter(10, 1, do_work, (sc,))

# Запуск программы
log("-= START =-")
s = sched.scheduler(time.time, time.sleep)
s.enter(5, 1, do_work, (s,))
s.run()
log("-= STOP =-")