import json
import random
from datetime import datetime
import time
import sched

class NewspaperArticle:
    def __init__(self, title, body):
        self.title = title
        self.body = body
        self.datetime = datetime.now().strftime("%A %d-%b-%Y %H:%M:%S")
        self.likes = random.randint(10, 100)

_I = 5
_TIME_SEC = 10
_LOG_FILE = f'json/log/serialize-{datetime.now().strftime("%Y%m%d")}.log'

def log(s):
    with open(_LOG_FILE, "a", encoding='utf-8') as f:
        f.writelines(f'{datetime.now().strftime("%H:%M:%S")} | {s} \n')

def to_dict(o):
    result = o.__dict__
    result["className"] = o.__class__.__name__
    return result

def generate_random_article(i):
    """Генерирует случайный заголовок и текст статьи."""
    title = f'Заголовок - {random.randint(1, 9999)}'
    body = f'Некоторый текст - {random.randint(1000, 9999999)}'
    return NewspaperArticle(title, body)

def send_json_data(i):
    try:
        art = generate_random_article(i)
        fd = f'json/download/{i}-{datetime.now().strftime("%Y%m%d%H%M%S")}-data.json'
        with open(fd, "x", encoding='utf-8') as f:
            json.dump(art, f, default=to_dict)
        log(f'Отправка {i} выполнена')
    except Exception as err:
        log(f'Ошибка отправки {i} - {err}')

_J = 0

def do_work(sc):
    global _J
    _J += 1
    print(f'--- {_J} ---')
    send_json_data(_J)
    if _J < _I:
        sc.enter(_TIME_SEC, 1, do_work, (sc,))

log("-= START =-")
s = sched.scheduler(time.time, time.sleep)
s.enter(1, 1, do_work, (s,))
s.run()
log("-= STOP =-")